;; Basic Visual Customization
(setq modus-vivendi-palette-overrides
      '((bg-main "#292D3E")
	      (bg-mode-line-active "#232635")
	      (border-mode-line-active "#232635")))
(set-face-attribute 'default nil
		                :font "JetBrains Mono"
		                :height 140)
(load-theme 'modus-vivendi t)
(set-frame-parameter (selected-frame) 'alpha-background 93)
(tool-bar-mode 0)
(menu-bar-mode 0)
(scroll-bar-mode 0)
(blink-cursor-mode 0)

(setq org-agenda-files '("~/tmp/org-video/Notes/Personal.org"
                         "~/tmp/org-video/Notes/Projects.org"
                         "~/tmp/org-video/Notes/Work.org"))

(setq org-tag-alist
      '(;; Places
        ("@home" . ?H)
        ("@work" . ?W)
        ("@pharmacy" . ?H)

        ;; Devices
        ("@computer" . ?C)
        ("@phone" . ?P)

        ;; Activities
        ("@planning" . ?n)
        ("@programming" . ?p)
        ("@writing" . ?w)
        ("@creative" . ?c)
        ("@email" . ?e)
        ("@calls" . ?a)
        ("@errands" . ?r)))

(global-set-key (kbd "C-c o a") #'org-agenda)

(setq org-log-done 'time)
(setq org-agenda-start-with-log-mode t)

(setq org-agenda-custom-commands
      '(("p" "Planning"
             ((tags-todo "+@planning"
                         ((org-agenda-overriding-header "Planning Tasks")))
              (tags-todo "-{.*}"
                         ((org-agenda-overriding-header "Untagged Tasks")))
              (todo ".*" ((org-agenda-files '("~/Notes/Inbox.org"))
                          (org-agenda-overriding-header "Unprocessed Inbox Items")))))

        ("d" "Daily Agenda"
         ((agenda "" ((org-agenda-span 'day)
		                  (org-deadline-warning-days 7)))
	        (tags-todo "+PRIORITY=\"A\""
		                 ((org-agenda-overriding-header "High Priority Tasks")))))

        ("w" "Weekly Review"
         ((agenda ""
                  ((org-agenda-overriding-header "Completed Tasks")
                   (org-agenda-skip-function '(org-agenda-skip-entry-if 'nottodo 'done))
		               (org-agenda-span 'week)))

          (agenda ""
                  ((org-agenda-overriding-header "Unfinished Scheduled Tasks")
                   (org-agenda-skip-function '(org-agenda-skip-entry-if 'todo 'done))
                   (org-agenda-span 'week)))))))
