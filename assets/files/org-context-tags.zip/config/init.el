;; Basic Visual Customization
(setq modus-vivendi-palette-overrides
      '((bg-main "#292D3E")
	(bg-mode-line-active "#232635")
	(border-mode-line-active "#232635")))
(set-face-attribute 'default nil
		    :font "JetBrains Mono"
		    :height 140)
(load-theme 'modus-vivendi t)
(set-frame-parameter (selected-frame) 'alpha-background 93)
(tool-bar-mode 0)
(menu-bar-mode 0)
(scroll-bar-mode 0)
(blink-cursor-mode 0)

(setq org-agenda-files '("~/tmp/org-video/Notes/Personal.org"
                         "~/tmp/org-video/Notes/Projects.org"
                         "~/tmp/org-video/Notes/Work.org"))

(setq org-tag-alist
      '(;; Places
        ("@home" . ?H)
        ("@work" . ?W)
        ("@pharmacy" . ?H)

        ;; Devices
        ("@computer" . ?C)
        ("@phone" . ?P)

        ;; Activities
        ("@planning" . ?n)
        ("@programming" . ?p)
        ("@writing" . ?w)
        ("@creative" . ?c)
        ("@email" . ?e)
        ("@calls" . ?a)
        ("@errands" . ?r)))

